<?php

// credentials for login into database
$host = "localhost";
$username = "root";
$password = "";
$db = "register";
 $conn = mysqli_connect($host,$username,$password,$db);
 
   

     if(!$conn)                                                                                                                                    
     {
         echo "connect nhi hua h";
     }

// form handling start


     if(isset($_POST['submit']))
{

$fname = $_POST['fname'];
$phone = $_POST['phone'];
$email = $_POST['email'];



$sql = "INSERT INTO registertable (fname,phone,email) VALUES ('$fname','$phone','$email')";

$result = mysqli_query($conn,$sql);
if($result)
{
    echo $fname."</br>";
    echo $phone."</br>";
    echo $email."</br>";
}
else{
    echo"sorry";
}
}


?>